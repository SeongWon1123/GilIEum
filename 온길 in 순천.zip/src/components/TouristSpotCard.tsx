import { MapPin, Clock, Star, Phone, Timer } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface TouristSpot {
  id: number;
  name: string;
  category: string;
  description: string;
  rating: number;
  address: string;
  phone: string;
  keywords: string[];
  image: string;
  openTime: string;
  visitDuration: string;
}

interface TouristSpotCardProps {
  touristSpot: TouristSpot;
  index: number;
}

export function TouristSpotCard({ touristSpot, index }: TouristSpotCardProps) {
  return (
    <div className="min-w-[340px] max-w-[340px] bg-white rounded-2xl shadow-xl overflow-hidden flex-shrink-0 hover:shadow-2xl hover:scale-[1.02] transition-all duration-300 border border-emerald-100">
      {/* 순서 배지 */}
      <div className="relative">
        <ImageWithFallback
          src={touristSpot.image}
          alt={touristSpot.name}
          className="w-full h-52 object-cover"
        />
        <div className="absolute top-4 left-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-full w-12 h-12 flex items-center justify-center shadow-xl font-bold text-lg">
          {index + 1}
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-black/50 to-transparent"></div>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <h3 className="text-xl mb-2 text-gray-800">{touristSpot.name}</h3>
            <span className="inline-block bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-700 text-sm px-4 py-1.5 rounded-full font-medium">
              {touristSpot.category}
            </span>
          </div>
          <div className="flex items-center bg-yellow-50 px-3 py-1.5 rounded-xl border border-yellow-200">
            <Star className="w-4 h-4 text-yellow-500 fill-current mr-1" />
            <span className="text-sm font-medium text-gray-700">{touristSpot.rating}</span>
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-5 leading-relaxed">{touristSpot.description}</p>

        <div className="space-y-2.5 text-sm text-gray-600 mb-5 bg-gray-50 rounded-xl p-4">
          <div className="flex items-start">
            <MapPin className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0 text-emerald-500" />
            <span className="text-xs">{touristSpot.address}</span>
          </div>
          <div className="flex items-center">
            <Clock className="w-4 h-4 mr-2 flex-shrink-0 text-emerald-500" />
            <span className="text-xs">{touristSpot.openTime}</span>
          </div>
          <div className="flex items-center">
            <Timer className="w-4 h-4 mr-2 flex-shrink-0 text-emerald-500" />
            <span className="text-xs font-medium">소요: {touristSpot.visitDuration}</span>
          </div>
          <div className="flex items-center">
            <Phone className="w-4 h-4 mr-2 flex-shrink-0 text-emerald-500" />
            <span className="text-xs">{touristSpot.phone}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {touristSpot.keywords.map((keyword) => (
            <span
              key={keyword}
              className="bg-emerald-50 text-emerald-700 text-xs px-3 py-1 rounded-full font-medium border border-emerald-200"
            >
              #{keyword}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}