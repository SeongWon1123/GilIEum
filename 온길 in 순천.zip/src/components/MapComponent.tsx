import { MapPin } from 'lucide-react';

interface Restaurant {
  id: number;
  name: string;
  lat: number;
  lng: number;
  day?: number; // 몇일차 여행지인지
}

interface MapComponentProps {
  restaurants: Restaurant[];
  selectedDay?: number; // 현재 선택된 일차
}

export function MapComponent({ restaurants, selectedDay }: MapComponentProps) {
  // 실제로는 카카오맵 또는 네이버맵 API를 사용합니다
  // API 키가 필요하므로 여기서는 시각적 목업을 제공합니다
  
  // Day별 색상 매핑
  const getDayColor = (day: number) => {
    const colors = [
      'bg-blue-500 hover:bg-blue-600', // 1일차 - 파란색
      'bg-red-500 hover:bg-red-600', // 2일차 - 빨간색
      'bg-purple-500 hover:bg-purple-600', // 3일차
      'bg-pink-500 hover:bg-pink-600', // 4일차
      'bg-orange-500 hover:bg-orange-600', // 5일차
    ];
    return colors[(day - 1) % colors.length];
  };
  
  return (
    <div className="w-full h-full relative bg-gradient-to-br from-green-100 via-blue-50 to-green-50">
      {/* 지도 배경 이미지 (순천만 지역) */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <MapPin className="w-12 h-12 text-orange-500 mx-auto mb-2" />
          <p className="text-gray-600">순천 맛집 지도</p>
          <p className="text-sm text-gray-400 mt-2">
            실제 서비스에서는 카카오맵 API를 연동합니다
          </p>
        </div>
      </div>

      {/* 맛집 마커들 */}
      <div className="absolute inset-0">
        {restaurants.map((restaurant, index) => {
          // 화면에 분산되도록 위치 계산 (실제로는 위도/경도 기반)
          const positions = [
            { top: '20%', left: '30%' },
            { top: '40%', left: '60%' },
            { top: '60%', left: '40%' },
            { top: '30%', left: '70%' },
            { top: '70%', left: '25%' },
            { top: '50%', left: '50%' },
            { top: '35%', left: '45%' },
          ];
          const position = positions[index % positions.length];

          return (
            <div
              key={restaurant.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{ top: position.top, left: position.left }}
            >
              <div className="relative group cursor-pointer">
                <div
                  className={`text-white rounded-full w-10 h-10 flex items-center justify-center shadow-lg ${getDayColor(restaurant.day || 1)}`}
                >
                  {index + 1}
                </div>
                <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-white px-3 py-2 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                  <p className="text-sm">{restaurant.name}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 실제 API 연동 안내 */}
      <div className="absolute bottom-4 left-4 bg-white px-4 py-2 rounded-lg shadow text-sm text-gray-600">
        <p>💡 카카오맵 API 연동 방법:</p>
        <p className="text-xs mt-1">1. developers.kakao.com에서 API 키 발급</p>
        <p className="text-xs">2. script 태그로 kakao.maps.load() 호출</p>
      </div>
    </div>
  );
}