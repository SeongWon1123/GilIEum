import { useNavigate } from 'react-router';
import { Utensils } from 'lucide-react';

export function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white flex flex-col items-center justify-center p-4">
      <div className="text-center">
        <div className="flex items-center justify-center mb-6">
          <Utensils className="w-16 h-16 text-orange-500" />
        </div>
        <h1 className="text-5xl mb-4 text-orange-600">온식</h1>
        <p className="text-xl text-gray-600 mb-8">순천 맛집 여행 플래너</p>
        <p className="text-gray-500 mb-12 max-w-md">
          당신의 취향과 동반인 정보를 알려주시면<br />
          완벽한 순천 맛집 코스를 추천해드립니다
        </p>
        <div className="flex gap-4 justify-center">
          <button
            onClick={() => navigate('/input')}
            className="bg-orange-500 text-white px-8 py-4 rounded-full text-lg hover:bg-orange-600 transition-colors shadow-lg"
          >
            맛집 찾기
          </button>
          <button
            onClick={() => navigate('/ongil')}
            className="bg-white text-orange-500 border-2 border-orange-500 px-8 py-4 rounded-full text-lg hover:bg-orange-50 transition-colors shadow-lg"
          >
            온길 보러가기
          </button>
        </div>
      </div>
    </div>
  );
}