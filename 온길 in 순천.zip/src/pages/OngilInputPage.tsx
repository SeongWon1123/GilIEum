import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Users, Calendar, Tag, X } from 'lucide-react';

export function OngilInputPage() {
  const navigate = useNavigate();
  const [travelDays, setTravelDays] = useState(1);
  const [companions, setCompanions] = useState([{ age: '', gender: '' }]);
  const [keywords, setKeywords] = useState<string[]>([]);

  const availableKeywords = [
    {
      id: 'mountain',
      label: '산',
      image: 'https://images.unsplash.com/photo-1634712900413-cecb25c8ebd6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMHBlYWslMjBoaWtpbmd8ZW58MXx8fHwxNzY5OTI2OTIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'indoor',
      label: '실내 여행지',
      image: 'https://images.unsplash.com/photo-1726492741161-46ec6de8ab1a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRvb3IlMjBtdXNldW0lMjBnYWxsZXJ5fGVufDF8fHx8MTc2OTkyNjkyMXww&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'activity',
      label: '액티비티',
      image: 'https://images.unsplash.com/photo-1766483677150-3235ed9f8439?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJhZ2xpZGluZyUyMGFkdmVudHVyZSUyMGFjdGl2aXR5fGVufDF8fHx8MTc2OTkyNjkyMXww&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'culture',
      label: '문화·역사',
      image: 'https://images.unsplash.com/photo-1768295985326-c60d705a9693?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXN0b3JpYyUyMGN1bHR1cmFsJTIwc2l0ZSUyMGtvcmVhfGVufDF8fHx8MTc2OTkyNjkyMXww&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'theme-park',
      label: '테마파크',
      image: 'https://images.unsplash.com/photo-1626209025747-b41ee6ec191f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbXVzZW1lbnQlMjBwYXJrJTIwZmVycmlzJTIwd2hlZWx8ZW58MXx8fHwxNzY5OTI2OTIxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'beach',
      label: '바다',
      image: 'https://images.unsplash.com/photo-1598399929533-847def01aa41?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvY2VhbiUyMGJlYWNoJTIwc3Vuc2V0fGVufDF8fHx8MTc2OTg5MTMwMXww&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'temple',
      label: '사찰',
      image: 'https://images.unsplash.com/photo-1625736300986-175f07d0032b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidWRkaGlzdCUyMHRlbXBsZSUyMGFzaWF8ZW58MXx8fHwxNzY5OTI3NTAzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    },
    {
      id: 'night-view',
      label: '야경',
      image: 'https://images.unsplash.com/photo-1750810908078-a4729905bf4b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaXR5JTIwbmlnaHQlMjB2aWV3JTIwc2t5bGluZXxlbnwxfHx8fDE3Njk5Mjc1MDN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    },
  ];

  const addCompanion = () => {
    setCompanions([...companions, { age: '', gender: '' }]);
  };

  const removeCompanion = (index: number) => {
    if (companions.length > 1) {
      setCompanions(companions.filter((_, i) => i !== index));
    }
  };

  const updateCompanion = (index: number, field: 'age' | 'gender', value: string) => {
    const updated = [...companions];
    updated[index][field] = value;
    setCompanions(updated);
  };

  const toggleKeyword = (keyword: string) => {
    if (keywords.includes(keyword)) {
      setKeywords(keywords.filter(k => k !== keyword));
    } else {
      setKeywords([...keywords, keyword]);
    }
  };

  const handleSubmit = () => {
    const planData = {
      travelDays,
      companions,
      keywords,
    };
    localStorage.setItem('ongilPlanData', JSON.stringify(planData));
    navigate('/result');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      <div className="max-w-2xl mx-auto p-6 py-8">
        <button
          onClick={() => navigate('/')}
          className="mb-8 flex items-center text-emerald-700 hover:text-emerald-900 font-medium transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          홈으로
        </button>

        <div className="text-center mb-12">
          <h1 className="text-4xl mb-3 text-emerald-700">온길 in 순천</h1>
          <p className="text-gray-600">몇 가지만 알려주시면 완벽한 코스를 만들어드려요</p>
        </div>

        {/* 여행 기간 */}
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 mb-5 shadow-lg border border-emerald-100">
          <h2 className="text-xl mb-4 flex items-center text-gray-800">
            <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center mr-3">
              <Calendar className="w-4 h-4 text-emerald-600" />
            </div>
            여행 기간
          </h2>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={() => setTravelDays(Math.max(1, travelDays - 1))}
              className="w-10 h-10 bg-emerald-100 rounded-lg hover:bg-emerald-200 transition-colors flex items-center justify-center text-emerald-700 font-bold"
            >
              −
            </button>
            <div className="flex items-center gap-2 bg-gradient-to-r from-emerald-50 to-teal-50 px-6 py-3 rounded-xl min-w-[120px] justify-center">
              <span className="text-3xl text-emerald-700 font-bold">{travelDays}</span>
              <span className="text-lg text-gray-600">일</span>
            </div>
            <button
              onClick={() => setTravelDays(Math.min(7, travelDays + 1))}
              className="w-10 h-10 bg-emerald-100 rounded-lg hover:bg-emerald-200 transition-colors flex items-center justify-center text-emerald-700 font-bold"
            >
              +
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-3 text-center">
            하루 3-4개 명소 추천
          </p>
        </div>

        {/* 동반인 정보 */}
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 mb-5 shadow-lg border border-teal-100">
          <h2 className="text-xl mb-4 flex items-center text-gray-800">
            <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center mr-3">
              <Users className="w-4 h-4 text-teal-600" />
            </div>
            동반인 정보
          </h2>
          <div className="space-y-3">
            {companions.map((companion, index) => (
              <div key={index} className="relative bg-gradient-to-r from-teal-50/50 to-cyan-50/50 p-4 rounded-xl border border-teal-100">
                {companions.length > 1 && (
                  <button
                    onClick={() => removeCompanion(index)}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center shadow-md transition-colors z-10"
                    title="삭제"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-gray-600 mb-1.5 font-medium">연령대</label>
                    <select
                      value={companion.age}
                      onChange={(e) => updateCompanion(index, 'age', e.target.value)}
                      className="w-full px-3 py-2 border border-teal-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent bg-white text-sm"
                    >
                      <option value="">선택</option>
                      <option value="10대">10대</option>
                      <option value="20대">20대</option>
                      <option value="30대">30대</option>
                      <option value="40대">40대</option>
                      <option value="50대 이상">50대 이상</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-gray-600 mb-1.5 font-medium">성별</label>
                    <select
                      value={companion.gender}
                      onChange={(e) => updateCompanion(index, 'gender', e.target.value)}
                      className="w-full px-3 py-2 border border-teal-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent bg-white text-sm"
                    >
                      <option value="">선택</option>
                      <option value="남성">남성</option>
                      <option value="여성">여성</option>
                      <option value="기타">기타</option>
                    </select>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={addCompanion}
            className="w-full mt-3 text-teal-600 hover:text-teal-700 text-sm font-medium bg-teal-50 hover:bg-teal-100 px-4 py-2.5 rounded-lg transition-colors border border-teal-200"
          >
            + 동반인 추가
          </button>
        </div>

        {/* 여행 스타일 키워드 */}
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 mb-8 shadow-lg border border-cyan-100">
          <h2 className="text-xl mb-2 text-gray-800">
            원하는 여행 테마를 2개 이상 선택해 주세요. (최대 4개)
          </h2>
          <div className="grid grid-cols-3 gap-3 mt-6">
            {availableKeywords.map((keyword) => (
              <button
                key={keyword.id}
                onClick={() => {
                  if (keywords.includes(keyword.label)) {
                    toggleKeyword(keyword.label);
                  } else if (keywords.length < 4) {
                    toggleKeyword(keyword.label);
                  }
                }}
                className={`flex flex-col items-center gap-2 p-3 rounded-2xl transition-all ${
                  keywords.includes(keyword.label)
                    ? 'border-4 border-blue-500 bg-blue-50'
                    : 'border-2 border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <div className="w-20 h-20 rounded-full overflow-hidden">
                  <img
                    src={keyword.image}
                    alt={keyword.label}
                    className="w-full h-full object-cover"
                  />
                </div>
                <span className="text-xs font-medium text-gray-800 text-center">{keyword.label}</span>
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-white py-4 rounded-xl text-lg font-medium hover:from-emerald-600 hover:to-teal-600 transition-all shadow-lg hover:shadow-xl hover:scale-[1.02] transform duration-200"
        >
          여행 코스 만들기 →
        </button>
      </div>
    </div>
  );
}