import { useNavigate } from 'react-router';
import { Map, Compass, Mountain, Navigation } from 'lucide-react';

export function OngilHomePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50 relative overflow-hidden">
      {/* 배경 장식 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-64 h-64 bg-emerald-200/30 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-teal-200/30 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-cyan-200/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative min-h-screen flex flex-col items-center justify-center p-4">
        {/* 로고 섹션 */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="relative">
              <Mountain className="w-20 h-20 text-emerald-600" strokeWidth={1.5} />
              <Compass className="w-10 h-10 text-teal-600 absolute -bottom-2 -right-2" strokeWidth={2} />
            </div>
          </div>
          
          <h1 className="text-7xl mb-6 text-emerald-700" style={{ fontFamily: 'system-ui' }}>
            온길
          </h1>
          
          <div className="flex items-center justify-center gap-2 mb-4">
            <Map className="w-5 h-5 text-teal-600" />
            <p className="text-2xl text-gray-700">순천의 모든 여행</p>
          </div>
          
          <p className="text-gray-600 text-lg mb-3 max-w-lg mx-auto leading-relaxed">
            자연과 역사가 살아 숨쉬는 순천<br />
            당신만을 위한 특별한 여행 코스를 만들어드립니다
          </p>
          
          <div className="flex items-center justify-center gap-2 text-sm text-emerald-600 mb-12">
            <Navigation className="w-4 h-4" />
            <span>맞춤형 여행 계획 | 실시간 위치 피드백 | 순천 전문</span>
          </div>
        </div>

        {/* CTA 버튼 */}
        <button
          onClick={() => navigate('/input')}
          className="group relative bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-12 py-5 rounded-2xl text-xl hover:from-emerald-600 hover:to-teal-600 transition-all shadow-xl hover:shadow-2xl hover:scale-105 transform duration-300"
        >
          <span className="flex items-center gap-3">
            여행 시작하기
            <Compass className="w-6 h-6 group-hover:rotate-90 transition-transform duration-500" />
          </span>
        </button>
      </div>
    </div>
  );
}
