import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, X, Clock, DollarSign, MapPin, Phone, Star } from 'lucide-react';
import { MapComponent } from '../components/MapComponent';
import { TouristSpotCard } from '../components/TouristSpotCard';

interface TouristSpot {
  id: number;
  name: string;
  category: string;
  description: string;
  rating: number;
  address: string;
  phone: string;
  keywords: string[];
  lat: number;
  lng: number;
  image: string;
  openTime: string;
  visitDuration: string;
  day?: number; // 몇일차 여행지인지
  fee?: string; // 입장료
  facilities?: string[]; // 편의시설
  reviews?: { author: string; rating: number; comment: string; date: string }[]; // 리뷰
}

export function OngilResultPage() {
  const navigate = useNavigate();
  const [touristSpots, setTouristSpots] = useState<TouristSpot[]>([]);
  const [travelDays, setTravelDays] = useState(1);
  const [selectedDay, setSelectedDay] = useState<number | null>(null); // null이면 전체 보기
  const [selectedKeywords, setSelectedKeywords] = useState<string[]>([]); // 선택된 테마
  const [mobileView, setMobileView] = useState<'list' | 'map'>('list'); // 모바일 뷰 전환
  const [selectedSpot, setSelectedSpot] = useState<TouristSpot | null>(null); // 선택된 여행지 (모달용)

  useEffect(() => {
    // 페이지 로드 시 맨 위로 스크롤
    window.scrollTo(0, 0);
    
    const planData = localStorage.getItem('ongilPlanData');
    if (!planData) {
      navigate('/input');
      return;
    }

    const { travelDays: days = 1, keywords = [] } = JSON.parse(planData);
    setTravelDays(days);
    setSelectedKeywords(keywords);

    // 순천 관광명소 mock 데이터
    const allTouristSpots: TouristSpot[] = [
      {
        id: 1,
        name: '순천만 국가정원',
        category: '자연/정원',
        description: '세계 5대 연안습지 순천만과 아름다운 정원이 어우러진 대표 관광지',
        rating: 4.9,
        address: '전남 순천시 국가정원1호길 47',
        phone: '061-749-3006',
        keywords: ['자연', '사진', '힐링', '가족', '데이트'],
        lat: 34.8923,
        lng: 127.5012,
        image: 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?w=800',
        openTime: '09:00 - 18:00',
        visitDuration: '2-3시간',
        fee: '성인 8,000원 / 청소년 6,000원',
        facilities: ['주차장', '화장실', '식당', '카페', '기념품점'],
        reviews: [
          { author: '김민지', rating: 5, comment: '정말 아름다운 정원이에요. 사진 찍기 좋고 산책하기 완벽합니다!', date: '2024.01.15' },
          { author: '이준호', rating: 4.5, comment: '넓어서 시간 여유있게 가세요. 가족과 함께 즐기기 좋아요.', date: '2024.01.10' },
          { author: '박서연', rating: 5, comment: '계절마다 다른 꽃을 볼 수 있어서 좋아요. 강력 추천!', date: '2024.01.05' },
        ],
      },
      {
        id: 2,
        name: '낙안읍성 민속마을',
        category: '역사/문화',
        description: '조선시대 성곽과 전통 한옥이 보존된 역사 마을',
        rating: 4.7,
        address: '전남 순천시 낙안면 충민길 30',
        phone: '061-749-3893',
        keywords: ['역사', '문화', '사진', '체험', '가족'],
        lat: 34.9823,
        lng: 127.3456,
        image: 'https://images.unsplash.com/photo-1555400038-63f5ba517a47?w=800',
        openTime: '09:00 - 18:00',
        visitDuration: '1-2시간',
        fee: '성인 4,000원 / 청소년 2,000원',
        facilities: ['주차장', '화장실', '식당', '전통체험관'],
        reviews: [
          { author: '최영수', rating: 5, comment: '타임슬립한 기분! 한복 입고 걸으면 더 좋아요.', date: '2024.01.12' },
          { author: '정하윤', rating: 4, comment: '아이들 교육에 좋은 곳입니다. 역사 공부가 됩니다.', date: '2024.01.08' },
        ],
      },
      {
        id: 3,
        name: '순천만 자연생태공원',
        category: '자연/생태',
        description: '갈대밭과 S자 물길이 아름다운 생태 공원',
        rating: 4.8,
        address: '전남 순천시 순천만길 513-25',
        phone: '061-749-4007',
        keywords: ['자연', '힐링', '사진', '데이트', '친구'],
        lat: 34.8856,
        lng: 127.5094,
        image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800',
        openTime: '08:00 - 일몰시',
        visitDuration: '2-3시간',
        fee: '무료',
        facilities: ['주차장', '화장실', '전망대', '산책로'],
        reviews: [
          { author: '강지우', rating: 5, comment: '일몰 시간에 가면 정말 멋진 풍경을 볼 수 있어요!', date: '2024.01.14' },
          { author: '윤서아', rating: 4.5, comment: '갈대밭이 끝없이 펼쳐져 있어서 힐링됩니다.', date: '2024.01.11' },
        ],
      },
      {
        id: 4,
        name: '순천 드라마 촬영장',
        category: '문화/체험',
        description: '1960-80년대 거리를 재현한 드라마 촬영 세트장',
        rating: 4.5,
        address: '전남 순천시 비례골길 24',
        phone: '061-749-4003',
        keywords: ['문화', '사진', '체험', '가족', '친구'],
        lat: 34.9145,
        lng: 127.4234,
        image: 'https://images.unsplash.com/photo-1536244881128-b9e0151b8958?w=800',
        openTime: '09:00 - 18:00',
        visitDuration: '1-2시간',
      },
      {
        id: 5,
        name: '선암사',
        category: '역사/종교',
        description: '천년 고찰의 아름다운 전통 사찰',
        rating: 4.6,
        address: '전남 순천시 승주읍 선암사길 450',
        phone: '061-754-5247',
        keywords: ['역사', '힐링', '자연', '문화', '혼자'],
        lat: 34.9923,
        lng: 127.3234,
        image: 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=800',
        openTime: '07:00 - 18:00',
        visitDuration: '1-2시간',
      },
      {
        id: 6,
        name: '와온해변',
        category: '자연/해변',
        description: '조용하고 한적한 순천의 숨은 해변',
        rating: 4.4,
        address: '전남 순천시 해룡면 와온리',
        phone: '061-749-5834',
        keywords: ['자연', '힐링', '데이트', '사진', '친구'],
        lat: 34.8234,
        lng: 127.5678,
        image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800',
        openTime: '상시 개방',
        visitDuration: '1시간',
      },
      {
        id: 7,
        name: '순천문학관',
        category: '문화/전시',
        description: '순천 출신 문인들의 작품을 전시하는 문학 공간',
        rating: 4.3,
        address: '전남 순천시 장명로 30',
        phone: '061-749-6585',
        keywords: ['문화', '힐링', '혼자', '친구'],
        lat: 34.9456,
        lng: 127.4789,
        image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=800',
        openTime: '09:00 - 18:00',
        visitDuration: '1시간',
      },
      {
        id: 8,
        name: '조산 송광사',
        category: '역사/종교',
        description: '삼보사찰 중 하나인 유서 깊은 사찰',
        rating: 4.7,
        address: '전남 순천시 송광면 송광사안길 100',
        phone: '061-755-5306',
        keywords: ['역사', '자연', '힐링', '문화', '체험'],
        lat: 35.0023,
        lng: 127.2834,
        image: 'https://images.unsplash.com/photo-1590691225814-ab66a96fb1cf?w=800',
        openTime: '07:00 - 18:00',
        visitDuration: '2시간',
      },
      {
        id: 9,
        name: '순천만 천문대',
        category: '체험/교육',
        description: '별을 관측할 수 있는 천문대',
        rating: 4.5,
        address: '전남 순천시 해룡면 순천만길 513-25',
        phone: '061-749-4007',
        keywords: ['체험', '가족', '데이트', '친구'],
        lat: 34.8845,
        lng: 127.5123,
        image: 'https://images.unsplash.com/photo-1444703686981-a3abbc4d4fe3?w=800',
        openTime: '14:00 - 22:00',
        visitDuration: '1-2시간',
      },
      {
        id: 10,
        name: '봉화산 전망대',
        category: '자연/전망',
        description: '순천만과 순천 시내를 한눈에 볼 수 있는 전망대',
        rating: 4.6,
        address: '전남 순천시 해룡면 중흥리',
        phone: '061-749-4007',
        keywords: ['자연', '사진', '힐링', '데이트', '혼자'],
        lat: 34.8734,
        lng: 127.5234,
        image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800',
        openTime: '상시 개방',
        visitDuration: '30분',
      },
    ];

    // 키워드 매칭 점수 계산
    const getMatchScore = (spot: TouristSpot) => {
      let score = 0;
      selectedKeywords.forEach((keyword: string) => {
        if (spot.keywords.includes(keyword)) {
          score += 1;
        }
      });
      return score;
    };

    // 키워드 매칭 점수로 정렬
    const sortedSpots = allTouristSpots.sort((a, b) => getMatchScore(b) - getMatchScore(a));

    // 하루에 3-4개씩 추천
    const spotsPerDay = 4;
    const totalSpots = days * spotsPerDay;
    const selectedSpots = sortedSpots.slice(0, Math.min(totalSpots, sortedSpots.length));

    // 각 장소에 day 속성 추가
    const spotsWithDay = selectedSpots.map((spot, index) => ({
      ...spot,
      day: Math.floor(index / spotsPerDay) + 1,
    }));

    setTouristSpots(spotsWithDay);
  }, [navigate]);

  // 날짜별로 그룹화
  const groupByDay = () => {
    const spotsPerDay = 4;
    const grouped: TouristSpot[][] = [];
    
    for (let i = 0; i < travelDays; i++) {
      const daySpots = touristSpots.slice(i * spotsPerDay, (i + 1) * spotsPerDay);
      if (daySpots.length > 0) {
        grouped.push(daySpots);
      }
    }
    
    return grouped;
  };

  const dayGroups = groupByDay();
  
  // 선택된 일차의 장소만 필터링
  const selectedDaySpots = selectedDay ? touristSpots.filter(spot => spot.day === selectedDay) : touristSpots;
  
  // Day별 색상 반환
  const getDayColor = (day: number) => {
    const colors = [
      'bg-blue-500', // 1일차
      'bg-red-500', // 2일차
      'bg-purple-500', // 3일차
      'bg-pink-500', // 4일차
      'bg-orange-500', // 5일차
    ];
    return colors[(day - 1) % colors.length];
  };

  return (
    <div className="h-screen flex flex-col md:flex-row overflow-hidden bg-white">
      {/* 모바일 탭 네비게이션 */}
      <div className="md:hidden flex bg-white border-b border-gray-200 sticky top-0 z-20">
        <button
          onClick={() => setMobileView('list')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            mobileView === 'list'
              ? 'text-emerald-700 border-b-2 border-emerald-700'
              : 'text-gray-500'
          }`}
        >
          목록 보기
        </button>
        <button
          onClick={() => setMobileView('map')}
          className={`flex-1 py-3 text-sm font-medium transition-colors ${
            mobileView === 'map'
              ? 'text-emerald-700 border-b-2 border-emerald-700'
              : 'text-gray-500'
          }`}
        >
          지도 보기
        </button>
      </div>

      {/* 왼쪽 사이드바 (모바일에서는 조건부 렌더링) */}
      <div className={`${
        mobileView === 'list' ? 'flex' : 'hidden'
      } md:flex w-full md:w-[400px] flex-col bg-gradient-to-br from-emerald-50 to-teal-50 md:shadow-xl overflow-y-auto`}>
        {/* 헤더 */}
        <div className="bg-white/90 backdrop-blur-sm p-5 border-b border-emerald-200">
          <button
            onClick={() => navigate('/input')}
            className="flex items-center text-emerald-700 hover:text-emerald-900 font-medium mb-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            코스 재설정
          </button>
          
          <div className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-2xl p-5 shadow-lg">
            <h1 className="text-xl font-bold mb-2">순천 여행 코스</h1>
            <div className="flex items-center gap-2 text-sm opacity-90">
              <span>{travelDays}일</span>
            </div>
          </div>
        </div>

        {/* 여행 개요 */}
        <div className="bg-white mx-4 my-4 rounded-xl p-4 shadow-md">
          <div className="flex items-center gap-3 mb-3">
            <div className="bg-emerald-500 text-white rounded-full w-12 h-12 flex items-center justify-center text-lg font-bold">
              {travelDays}일
            </div>
            <div>
              <p className="text-sm text-gray-600">총 이동거리</p>
              <p className="text-lg font-bold text-emerald-700">24km</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 text-xs">
            {selectedKeywords.map((keyword) => (
              <span key={keyword} className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full">
                #{keyword}
              </span>
            ))}
          </div>
        </div>

        {/* 여행지 목록 */}
        <div className="flex-1 px-4 pb-4">
          {dayGroups.map((daySpots, dayIndex) => {
            // 이전 일차들의 장소 개수를 계산
            const previousSpotsCount = dayGroups
              .slice(0, dayIndex)
              .reduce((sum, spots) => sum + spots.length, 0);
            
            return (
              <div key={dayIndex} className="mb-6">
                <div 
                  className="flex items-center justify-between mb-3 cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => setSelectedDay(dayIndex + 1)}
                >
                  <h2 className={`text-lg font-bold ${selectedDay === dayIndex + 1 ? 'text-emerald-800' : 'text-gray-500'}`}>
                    Day {dayIndex + 1}
                  </h2>
                  <button className="text-xs text-gray-500 bg-white px-3 py-1 rounded-full">
                    일정편집
                  </button>
                </div>
                
                <div className="space-y-3">
                  {daySpots.map((spot, index) => (
                    <div
                      key={spot.id}
                      onClick={() => setSelectedSpot(spot)}
                      className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-shadow cursor-pointer border border-gray-100"
                    >
                      <div className="flex gap-3">
                        <div className="flex-shrink-0">
                          <div className={`${getDayColor(spot.day || 1)} text-white rounded-lg w-8 h-8 flex items-center justify-center font-bold text-sm`}>
                            {previousSpotsCount + index + 1}
                          </div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-1">
                            <h3 className="font-bold text-gray-900 truncate">{spot.name}</h3>
                          </div>
                          <p className="text-xs text-gray-500 mb-2">{spot.category}</p>
                          <p className="text-sm text-gray-700 line-clamp-2 mb-2">
                            {spot.description}
                          </p>
                          
                          <div className="flex items-center gap-2 text-xs text-gray-500">
                            <span>⏱️ {spot.visitDuration}</span>
                            <span>•</span>
                            <span>⭐ {spot.rating}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 오른쪽 지도 (모바일에서는 조건부 렌더링) */}
      <div className={`${
        mobileView === 'map' ? 'flex' : 'hidden'
      } md:flex flex-1 relative`}>
        <MapComponent restaurants={selectedDaySpots} selectedDay={selectedDay} />
        
        {/* 지도 상단 범례 - 선택된 일차만 표시 */}
        <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-3 rounded-lg shadow-lg">
          {selectedDay ? (
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${getDayColor(selectedDay)}`}></div>
              <span className="text-sm font-medium">{selectedDay}일차</span>
            </div>
          ) : (
            <div className="space-y-2">
              {Array.from({ length: travelDays }, (_, i) => i + 1).map((day) => (
                <div key={day} className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${getDayColor(day)}`}></div>
                  <span className="text-sm font-medium">{day}일차</span>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* 모바일 Day 선택 버튼 */}
        <div className="md:hidden absolute top-4 left-4 flex gap-2">
          <button
            onClick={() => setSelectedDay(null)}
            className={`px-3 py-2 rounded-lg text-xs font-medium shadow-md transition-colors ${
              selectedDay === null
                ? 'bg-emerald-700 text-white'
                : 'bg-white text-gray-700'
            }`}
          >
            전체
          </button>
          {Array.from({ length: travelDays }, (_, i) => i + 1).map((day) => (
            <button
              key={day}
              onClick={() => setSelectedDay(day)}
              className={`px-3 py-2 rounded-lg text-xs font-medium shadow-md transition-colors ${
                selectedDay === day
                  ? 'bg-emerald-700 text-white'
                  : 'bg-white text-gray-700'
              }`}
            >
              {day}일차
            </button>
          ))}
        </div>
      </div>

      {/* 상세 정보 모달 */}
      {selectedSpot && (
        <div 
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedSpot(null)}
        >
          <div 
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* 이미지 헤더 */}
            <div className="relative h-64 bg-gray-200">
              <img 
                src={selectedSpot.image} 
                alt={selectedSpot.name}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setSelectedSpot(null)}
                className="absolute top-4 right-4 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-colors"
              >
                <X className="w-5 h-5 text-gray-700" />
              </button>
            </div>

            {/* 컨텐츠 */}
            <div className="p-6">
              {/* 제목과 평점 */}
              <div className="mb-4">
                <div className="flex items-start justify-between mb-2">
                  <h2 className="text-2xl font-bold text-gray-900">{selectedSpot.name}</h2>
                  <div className="flex items-center gap-1 bg-emerald-50 px-3 py-1 rounded-full">
                    <Star className="w-4 h-4 text-emerald-600 fill-emerald-600" />
                    <span className="text-sm font-bold text-emerald-700">{selectedSpot.rating}</span>
                  </div>
                </div>
                <p className="text-sm text-gray-500">{selectedSpot.category}</p>
                <p className="text-gray-700 mt-2">{selectedSpot.description}</p>
              </div>

              {/* 기본 정보 */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <Clock className="w-5 h-5 text-emerald-600 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500 mb-1">운영시간</p>
                    <p className="text-sm font-medium text-gray-900">{selectedSpot.openTime}</p>
                    <p className="text-xs text-gray-500 mt-1">방문 소요: {selectedSpot.visitDuration}</p>
                  </div>
                </div>

                {selectedSpot.fee && (
                  <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <DollarSign className="w-5 h-5 text-emerald-600 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500 mb-1">입장료</p>
                      <p className="text-sm font-medium text-gray-900">{selectedSpot.fee}</p>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <MapPin className="w-5 h-5 text-emerald-600 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500 mb-1">주소</p>
                    <p className="text-sm font-medium text-gray-900">{selectedSpot.address}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <Phone className="w-5 h-5 text-emerald-600 mt-0.5" />
                  <div>
                    <p className="text-xs text-gray-500 mb-1">전화번호</p>
                    <p className="text-sm font-medium text-gray-900">{selectedSpot.phone}</p>
                  </div>
                </div>
              </div>

              {/* 편의시설 */}
              {selectedSpot.facilities && selectedSpot.facilities.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">편의시설</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedSpot.facilities.map((facility, index) => (
                      <span 
                        key={index}
                        className="bg-emerald-50 text-emerald-700 px-3 py-1.5 rounded-lg text-sm font-medium"
                      >
                        {facility}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* 리뷰 */}
              {selectedSpot.reviews && selectedSpot.reviews.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">방문자 리뷰</h3>
                  <div className="space-y-4">
                    {selectedSpot.reviews.map((review, index) => (
                      <div key={index} className="border-b border-gray-100 pb-4 last:border-0">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-900">{review.author}</span>
                            <div className="flex items-center gap-1">
                              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                              <span className="text-sm text-gray-600">{review.rating}</span>
                            </div>
                          </div>
                          <span className="text-xs text-gray-400">{review.date}</span>
                        </div>
                        <p className="text-sm text-gray-700">{review.comment}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}