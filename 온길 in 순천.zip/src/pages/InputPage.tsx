import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Users, Tag, Plus, X, ChevronUp, ChevronDown, UtensilsCrossed, Coffee } from 'lucide-react';

interface PlaceOrder {
  id: number;
  type: 'restaurant' | 'cafe';
}

export function InputPage() {
  const navigate = useNavigate();
  const [placeOrder, setPlaceOrder] = useState<PlaceOrder[]>([]);
  const [nextId, setNextId] = useState(1);
  const [companions, setCompanions] = useState([{ age: '', gender: '' }]);
  const [keywords, setKeywords] = useState<string[]>([]);

  const availableKeywords = ['자연', 'SNS 핫플', '전통', '모던', '한식', '양식', '일식', '카페', '뷰맛집', '가성비'];

  const addPlace = (type: 'restaurant' | 'cafe') => {
    setPlaceOrder([...placeOrder, { id: nextId, type }]);
    setNextId(nextId + 1);
  };

  const removePlace = (id: number) => {
    setPlaceOrder(placeOrder.filter(place => place.id !== id));
  };

  const movePlaceUp = (index: number) => {
    if (index === 0) return;
    const newOrder = [...placeOrder];
    [newOrder[index - 1], newOrder[index]] = [newOrder[index], newOrder[index - 1]];
    setPlaceOrder(newOrder);
  };

  const movePlaceDown = (index: number) => {
    if (index === placeOrder.length - 1) return;
    const newOrder = [...placeOrder];
    [newOrder[index], newOrder[index + 1]] = [newOrder[index + 1], newOrder[index]];
    setPlaceOrder(newOrder);
  };

  const addCompanion = () => {
    setCompanions([...companions, { age: '', gender: '' }]);
  };

  const updateCompanion = (index: number, field: 'age' | 'gender', value: string) => {
    const updated = [...companions];
    updated[index][field] = value;
    setCompanions(updated);
  };

  const toggleKeyword = (keyword: string) => {
    if (keywords.includes(keyword)) {
      setKeywords(keywords.filter(k => k !== keyword));
    } else {
      setKeywords([...keywords, keyword]);
    }
  };

  const handleSubmit = () => {
    const planData = {
      placeOrder,
      companions,
      keywords,
    };
    localStorage.setItem('planData', JSON.stringify(planData));
    navigate('/result');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto p-6">
        <button
          onClick={() => navigate('/')}
          className="mb-6 flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          돌아가기
        </button>

        <h1 className="text-3xl mb-8 text-orange-600">맛집 계획 만들기</h1>

        {/* 방문 순서 */}
        <div className="bg-white rounded-lg p-6 mb-6 shadow-sm">
          <h2 className="text-xl mb-4 flex items-center">
            <Tag className="w-5 h-5 mr-2 text-orange-500" />
            방문 순서
          </h2>
          
          {/* 장소 추가 버튼 */}
          <div className="flex gap-3 mb-4">
            <button
              onClick={() => addPlace('restaurant')}
              className="flex-1 flex items-center justify-center gap-2 bg-orange-50 text-orange-600 px-4 py-3 rounded-lg hover:bg-orange-100 transition-colors border-2 border-orange-200"
            >
              <UtensilsCrossed className="w-5 h-5" />
              밥집 추가
            </button>
            <button
              onClick={() => addPlace('cafe')}
              className="flex-1 flex items-center justify-center gap-2 bg-amber-50 text-amber-600 px-4 py-3 rounded-lg hover:bg-amber-100 transition-colors border-2 border-amber-200"
            >
              <Coffee className="w-5 h-5" />
              카페 추가
            </button>
          </div>

          {/* 추가된 장소 리스트 */}
          {placeOrder.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <p>방문할 장소를 순서대로 추가해주세요</p>
            </div>
          ) : (
            <div className="space-y-2">
              {placeOrder.map((place, index) => (
                <div
                  key={place.id}
                  className="flex items-center gap-3 bg-gray-50 p-3 rounded-lg"
                >
                  <div className="flex flex-col gap-1">
                    <button
                      onClick={() => movePlaceUp(index)}
                      disabled={index === 0}
                      className="text-gray-400 hover:text-gray-600 disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <ChevronUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => movePlaceDown(index)}
                      disabled={index === placeOrder.length - 1}
                      className="text-gray-400 hover:text-gray-600 disabled:opacity-30 disabled:cursor-not-allowed"
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </div>
                  
                  <div className="bg-orange-500 text-white rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0">
                    {index + 1}
                  </div>
                  
                  <div className="flex items-center gap-2 flex-1">
                    {place.type === 'restaurant' ? (
                      <>
                        <UtensilsCrossed className="w-5 h-5 text-orange-600" />
                        <span className="font-medium text-orange-600">밥집</span>
                      </>
                    ) : (
                      <>
                        <Coffee className="w-5 h-5 text-amber-600" />
                        <span className="font-medium text-amber-600">카페</span>
                      </>
                    )}
                  </div>
                  
                  <button
                    onClick={() => removePlace(place.id)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 동반인 정보 */}
        <div className="bg-white rounded-lg p-6 mb-6 shadow-sm">
          <h2 className="text-xl mb-4 flex items-center">
            <Users className="w-5 h-5 mr-2 text-orange-500" />
            동반인 정보
          </h2>
          {companions.map((companion, index) => (
            <div key={index} className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm text-gray-600 mb-2">연령대</label>
                <select
                  value={companion.age}
                  onChange={(e) => updateCompanion(index, 'age', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">선택하세요</option>
                  <option value="10대">10대</option>
                  <option value="20대">20대</option>
                  <option value="30대">30대</option>
                  <option value="40대">40대</option>
                  <option value="50대 이상">50대 이상</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-2">성별</label>
                <select
                  value={companion.gender}
                  onChange={(e) => updateCompanion(index, 'gender', e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="">선택하세요</option>
                  <option value="남성">남성</option>
                  <option value="여성">여성</option>
                  <option value="기타">기타</option>
                </select>
              </div>
            </div>
          ))}
          <button
            onClick={addCompanion}
            className="text-orange-500 hover:text-orange-600 text-sm"
          >
            + 동반인 추가
          </button>
        </div>

        {/* 키워드 */}
        <div className="bg-white rounded-lg p-6 mb-8 shadow-sm">
          <h2 className="text-xl mb-4">선호 키워드</h2>
          <div className="flex flex-wrap gap-2">
            {availableKeywords.map((keyword) => (
              <button
                key={keyword}
                onClick={() => toggleKeyword(keyword)}
                className={`px-4 py-2 rounded-full transition-colors ${
                  keywords.includes(keyword)
                    ? 'bg-orange-500 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {keyword}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          className="w-full bg-orange-500 text-white py-4 rounded-lg text-lg hover:bg-orange-600 transition-colors shadow-lg"
        >
          맛집 추천받기
        </button>
      </div>
    </div>
  );
}