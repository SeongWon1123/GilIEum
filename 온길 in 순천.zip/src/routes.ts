import { createBrowserRouter } from "react-router";
import { OngilHomePage } from "./pages/OngilHomePage";
import { OngilInputPage } from "./pages/OngilInputPage";
import { OngilResultPage } from "./pages/OngilResultPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: OngilHomePage,
  },
  {
    path: "/input",
    Component: OngilInputPage,
  },
  {
    path: "/result",
    Component: OngilResultPage,
  },
]);