
  # 온길 in 순천

  This is a code bundle for 온길 in 순천. The original project is available at https://www.figma.com/design/Qjb5r4OQbQ8jv1yThikcVH/%EC%98%A8%EA%B8%B8-in-%EC%88%9C%EC%B2%9C.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  