import { X, MapPin, Clock, Star, Phone, Wifi, Utensils, ParkingCircle, Accessibility } from 'lucide-react';

interface MenuItem {
  name: string;
  price: string;
}

interface Review {
  author: string;
  rating: number;
  comment: string;
  date: string;
}

interface Amenity {
  name: string;
  available: boolean;
}

interface Restaurant {
  id: number;
  name: string;
  category: string;
  description: string;
  rating: number;
  address: string;
  phone: string;
  keywords: string[];
  image: string;
  openTime: string;
  menu?: MenuItem[];
  reviews?: Review[];
  amenities?: Amenity[];
}

interface RestaurantDetailModalProps {
  restaurant: Restaurant;
  onClose: () => void;
}

export function RestaurantDetailModal({ restaurant, onClose }: RestaurantDetailModalProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto my-8">
        {/* 헤더 이미지 */}
        <div className="relative">
          <img
            src={restaurant.image}
            alt={restaurant.name}
            className="w-full h-48 md:h-64 object-cover"
          />
          <button
            onClick={onClose}
            className="absolute top-3 right-3 bg-white rounded-full w-8 h-8 md:w-10 md:h-10 flex items-center justify-center shadow-lg hover:bg-gray-100 transition-colors"
          >
            <X className="w-5 h-5 md:w-6 md:h-6" />
          </button>
        </div>

        <div className="p-4 md:p-6">
          {/* 기본 정보 */}
          <div className="mb-6">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h2 className="text-2xl md:text-3xl mb-2">{restaurant.name}</h2>
                <span className="inline-block bg-orange-100 text-orange-700 text-sm px-3 py-1 rounded-full">
                  {restaurant.category}
                </span>
              </div>
              <div className="flex items-center bg-yellow-50 px-3 py-2 rounded-lg">
                <Star className="w-5 h-5 text-yellow-500 fill-current mr-1" />
                <span className="text-lg">{restaurant.rating}</span>
              </div>
            </div>
            <p className="text-gray-600 mt-3">{restaurant.description}</p>
          </div>

          {/* 연락처 및 영업시간 */}
          <div className="space-y-3 mb-6 pb-6 border-b">
            <div className="flex items-start">
              <MapPin className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0 text-gray-400" />
              <span className="text-gray-700">{restaurant.address}</span>
            </div>
            <div className="flex items-center">
              <Clock className="w-5 h-5 mr-3 flex-shrink-0 text-gray-400" />
              <span className="text-gray-700">{restaurant.openTime}</span>
            </div>
            <div className="flex items-center">
              <Phone className="w-5 h-5 mr-3 flex-shrink-0 text-gray-400" />
              <a href={`tel:${restaurant.phone}`} className="text-orange-500 hover:text-orange-600">
                {restaurant.phone}
              </a>
            </div>
          </div>

          {/* 메뉴 및 가격 */}
          {restaurant.menu && restaurant.menu.length > 0 && (
            <div className="mb-6 pb-6 border-b">
              <h3 className="text-xl mb-4 flex items-center">
                <Utensils className="w-5 h-5 mr-2 text-orange-500" />
                메뉴 및 가격
              </h3>
              <div className="space-y-2">
                {restaurant.menu.map((item, index) => (
                  <div key={index} className="flex justify-between items-center bg-gray-50 p-3 rounded-lg">
                    <span className="text-gray-700">{item.name}</span>
                    <span className="font-medium text-orange-600">{item.price}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 편의시설 */}
          {restaurant.amenities && restaurant.amenities.length > 0 && (
            <div className="mb-6 pb-6 border-b">
              <h3 className="text-xl mb-4">편의시설</h3>
              <div className="grid grid-cols-2 gap-3">
                {restaurant.amenities.map((amenity, index) => (
                  <div
                    key={index}
                    className={`flex items-center gap-2 p-3 rounded-lg ${
                      amenity.available ? 'bg-green-50 text-green-700' : 'bg-gray-50 text-gray-400'
                    }`}
                  >
                    {amenity.name === '무료 Wi-Fi' && <Wifi className="w-4 h-4" />}
                    {amenity.name === '주차 가능' && <ParkingCircle className="w-4 h-4" />}
                    {amenity.name === '장애인 편의' && <Accessibility className="w-4 h-4" />}
                    <span className="text-sm">{amenity.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 리뷰 */}
          {restaurant.reviews && restaurant.reviews.length > 0 && (
            <div className="mb-4">
              <h3 className="text-xl mb-4">고객 리뷰</h3>
              <div className="space-y-4">
                {restaurant.reviews.map((review, index) => (
                  <div key={index} className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-gray-700">{review.author}</span>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="text-sm ml-1">{review.rating}</span>
                        </div>
                      </div>
                      <span className="text-xs text-gray-400">{review.date}</span>
                    </div>
                    <p className="text-gray-600 text-sm">{review.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 키워드 */}
          <div className="flex flex-wrap gap-2 mt-4">
            {restaurant.keywords.map((keyword) => (
              <span
                key={keyword}
                className="bg-gray-100 text-gray-700 text-sm px-3 py-1 rounded-full"
              >
                #{keyword}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
