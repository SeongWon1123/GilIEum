import { MapPin } from 'lucide-react';

interface Restaurant {
  id: number;
  name: string;
  lat: number;
  lng: number;
}

interface MapComponentProps {
  restaurants: Restaurant[];
}

export function MapComponent({ restaurants }: MapComponentProps) {
  // 실제로는 카카오맵 또는 네이버맵 API를 사용합니다
  // API 키가 필요하므로 여기서는 시각적 목업을 제공합니다
  
  return (
    <div className="w-full h-full relative bg-gradient-to-br from-green-100 via-blue-50 to-green-50">
      {/* 지도 배경 이미지 (순천만 지역) */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center px-4">
          <MapPin className="w-8 h-8 md:w-12 md:h-12 text-orange-500 mx-auto mb-2" />
          <p className="text-sm md:text-base text-gray-600">순천 맛집 지도</p>
          <p className="text-xs md:text-sm text-gray-400 mt-2">
            실제 서비스에서는 카카오맵 API를 연동합니다
          </p>
        </div>
      </div>

      {/* 맛집 마커들 */}
      <div className="absolute inset-0">
        {restaurants.map((restaurant, index) => {
          // 화면에 분산되도록 위치 계산 (실제로는 위도/경도 기반)
          const positions = [
            { top: '20%', left: '30%' },
            { top: '40%', left: '60%' },
            { top: '60%', left: '40%' },
            { top: '30%', left: '70%' },
            { top: '70%', left: '25%' },
            { top: '50%', left: '50%' },
            { top: '35%', left: '45%' },
          ];
          const position = positions[index % positions.length];

          return (
            <div
              key={restaurant.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{ top: position.top, left: position.left }}
            >
              <div className="relative group cursor-pointer">
                <div className="bg-orange-500 text-white rounded-full w-8 h-8 md:w-10 md:h-10 flex items-center justify-center shadow-lg hover:bg-orange-600 transition-colors text-sm md:text-base">
                  {index + 1}
                </div>
                <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-white px-2 md:px-3 py-1 md:py-2 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                  <p className="text-xs md:text-sm">{restaurant.name}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 실제 API 연동 안내 */}
      <div className="absolute bottom-2 left-2 md:bottom-4 md:left-4 bg-white px-3 py-1.5 md:px-4 md:py-2 rounded-lg shadow text-xs md:text-sm text-gray-600">
        <p>💡 카카오맵 API 연동 방법:</p>
        <p className="text-xs mt-1 hidden md:block">1. developers.kakao.com에서 API 키 발급</p>
        <p className="text-xs hidden md:block">2. script 태그로 kakao.maps.load() 호출</p>
      </div>
    </div>
  );
}