import { MapPin, Clock, Star, Phone } from 'lucide-react';

interface Restaurant {
  id: number;
  name: string;
  category: string;
  description: string;
  rating: number;
  address: string;
  phone: string;
  keywords: string[];
  image: string;
  openTime: string;
}

interface RestaurantCardProps {
  restaurant: Restaurant;
  index: number;
  onClick?: () => void;
}

export function RestaurantCard({ restaurant, index, onClick }: RestaurantCardProps) {
  return (
    <div 
      onClick={onClick}
      className="min-w-[280px] max-w-[280px] md:min-w-[320px] md:max-w-[320px] bg-white rounded-lg shadow-lg overflow-hidden flex-shrink-0 hover:shadow-xl transition-shadow cursor-pointer"
    >
      {/* 순서 배지 */}
      <div className="relative">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-40 md:h-48 object-cover"
        />
        <div className="absolute top-2 left-2 md:top-3 md:left-3 bg-orange-500 text-white rounded-full w-8 h-8 md:w-10 md:h-10 flex items-center justify-center shadow-lg">
          <span className="text-base md:text-lg">{index + 1}</span>
        </div>
      </div>

      <div className="p-4 md:p-5">
        <div className="flex items-start justify-between mb-2">
          <div>
            <h3 className="text-lg md:text-xl mb-1">{restaurant.name}</h3>
            <span className="inline-block bg-orange-100 text-orange-700 text-xs md:text-sm px-2 md:px-3 py-1 rounded-full">
              {restaurant.category}
            </span>
          </div>
          <div className="flex items-center bg-yellow-50 px-2 py-1 rounded">
            <Star className="w-3 h-3 md:w-4 md:h-4 text-yellow-500 fill-current mr-1" />
            <span className="text-xs md:text-sm">{restaurant.rating}</span>
          </div>
        </div>

        <p className="text-gray-600 text-xs md:text-sm mb-3 md:mb-4">{restaurant.description}</p>

        <div className="space-y-1.5 md:space-y-2 text-xs md:text-sm text-gray-600 mb-3 md:mb-4">
          <div className="flex items-start">
            <MapPin className="w-3 h-3 md:w-4 md:h-4 mr-2 mt-0.5 flex-shrink-0 text-gray-400" />
            <span className="line-clamp-2">{restaurant.address}</span>
          </div>
          <div className="flex items-center">
            <Clock className="w-3 h-3 md:w-4 md:h-4 mr-2 flex-shrink-0 text-gray-400" />
            <span>{restaurant.openTime}</span>
          </div>
          <div className="flex items-center">
            <Phone className="w-3 h-3 md:w-4 md:h-4 mr-2 flex-shrink-0 text-gray-400" />
            <span>{restaurant.phone}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-1 md:gap-1.5">
          {restaurant.keywords.map((keyword) => (
            <span
              key={keyword}
              className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded"
            >
              #{keyword}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}