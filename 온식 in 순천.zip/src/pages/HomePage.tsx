import { useNavigate } from 'react-router';
import { Utensils } from 'lucide-react';

export function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white flex flex-col items-center justify-center p-4">
      <div className="text-center">
        <div className="flex items-center justify-center mb-4 md:mb-6">
          <Utensils className="w-12 h-12 md:w-16 md:h-16 text-orange-500" />
        </div>
        <h1 className="text-4xl md:text-5xl mb-3 md:mb-4 text-orange-600">온식</h1>
        <p className="text-lg md:text-xl text-gray-600 mb-6 md:mb-8">순천 맛집 여행 플래너</p>
        <p className="text-sm md:text-base text-gray-500 mb-8 md:mb-12 max-w-md px-4">
          당신의 취향과 동반인 정보를 알려주시면<br />
          완벽한 순천 맛집 코스를 추천해드립니다
        </p>
        <button
          onClick={() => navigate('/input')}
          className="bg-orange-500 text-white px-6 md:px-8 py-3 md:py-4 rounded-full text-base md:text-lg hover:bg-orange-600 transition-colors shadow-lg"
        >
          시작하기
        </button>
      </div>
    </div>
  );
}