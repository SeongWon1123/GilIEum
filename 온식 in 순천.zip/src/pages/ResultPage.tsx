import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft } from 'lucide-react';
import { MapComponent } from '../components/MapComponent';
import { RestaurantCard } from '../components/RestaurantCard';
import { RestaurantDetailModal } from '../components/RestaurantDetailModal';

interface PlaceOrder {
  id: number;
  type: 'restaurant' | 'cafe';
}

interface MenuItem {
  name: string;
  price: string;
}

interface Review {
  author: string;
  rating: number;
  comment: string;
  date: string;
}

interface Amenity {
  name: string;
  available: boolean;
}

interface Restaurant {
  id: number;
  name: string;
  category: string;
  description: string;
  rating: number;
  address: string;
  phone: string;
  keywords: string[];
  lat: number;
  lng: number;
  image: string;
  openTime: string;
  menu?: MenuItem[];
  reviews?: Review[];
  amenities?: Amenity[];
}

export function ResultPage() {
  const navigate = useNavigate();
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);

  useEffect(() => {
    // 페이지 로드 시 맨 위로 스크롤
    window.scrollTo(0, 0);
    
    const planData = localStorage.getItem('planData');
    if (!planData) {
      navigate('/input');
      return;
    }

    const { placeOrder = [], keywords = [] } = JSON.parse(planData);

    // placeOrder가 비어있으면 입력 페이지로 리다이렉트
    if (!placeOrder || placeOrder.length === 0) {
      navigate('/input');
      return;
    }

    // 순천 맛집 mock 데이터
    const allRestaurants: Restaurant[] = [
      {
        id: 1,
        name: '순천만 정원 한정식',
        category: '한식',
        description: '순천만의 신선한 재료로 만든 전통 한정식',
        rating: 4.8,
        address: '전남 순천시 순천만길 513-25',
        phone: '061-123-4567',
        keywords: ['자연', '전통', '한식', '뷰맛집'],
        lat: 34.8856,
        lng: 127.5094,
        image: 'https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?w=800',
        openTime: '11:00 - 21:00',
        menu: [
          { name: '한정식 특선', price: '35,000원' },
          { name: '한정식 기본', price: '25,000원' },
          { name: '제철 생선구이', price: '18,000원' },
          { name: '된장찌개 정식', price: '12,000원' },
        ],
        reviews: [
          { author: '김민수', rating: 5, comment: '음식도 맛있고 순천만이 보이는 뷰가 정말 좋아요!', date: '2025.01.25' },
          { author: '이지은', rating: 4.5, comment: '신선한 재료로 정성스럽게 만든 한정식이 일품입니다.', date: '2025.01.20' },
          { author: '박준호', rating: 5, comment: '가족들과 함께 방문했는데 모두 만족했어요. 추천합니다!', date: '2025.01.15' },
        ],
        amenities: [
          { name: '무료 Wi-Fi', available: true },
          { name: '주차 가능', available: true },
          { name: '장애인 편의', available: true },
        ],
      },
      {
        id: 2,
        name: '동천 파스타',
        category: '양식',
        description: 'SNS에서 핫한 분위기 좋은 이탈리안 레스토랑',
        rating: 4.6,
        address: '전남 순천시 중앙로 123',
        phone: '061-234-5678',
        keywords: ['SNS 핫플', '모던', '양식'],
        lat: 34.9506,
        lng: 127.4872,
        image: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=800',
        openTime: '11:30 - 22:00',
        menu: [
          { name: '트러플 크림 파스타', price: '22,000원' },
          { name: '알리오올리오', price: '16,000원' },
          { name: '까르보나라', price: '17,000원' },
          { name: '마르게리타 피자', price: '19,000원' },
        ],
        reviews: [
          { author: '최수진', rating: 5, comment: '인테리어가 너무 예쁘고 파스타 맛도 최고예요!', date: '2025.01.28' },
          { author: '강민지', rating: 4, comment: '분위기 좋고 음식도 맛있어요. 사진 찍기 좋습니다.', date: '2025.01.22' },
        ],
        amenities: [
          { name: '무료 Wi-Fi', available: true },
          { name: '주차 가능', available: false },
          { name: '장애인 편의', available: true },
        ],
      },
      {
        id: 3,
        name: '순천 오마카세',
        category: '일식',
        description: '신선한 회와 정성스러운 오마카세 코스',
        rating: 4.9,
        address: '전남 순천시 해룡면 순천만길 45',
        phone: '061-345-6789',
        keywords: ['모던', '일식', 'SNS 핫플'],
        lat: 34.8645,
        lng: 127.5234,
        image: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=800',
        openTime: '12:00 - 22:00',
        menu: [
          { name: '특선 오마카세', price: '80,000원' },
          { name: '프리미엄 오마카세', price: '120,000원' },
          { name: '모둠회 (대)', price: '65,000원' },
          { name: '모둠회 (중)', price: '45,000원' },
        ],
        reviews: [
          { author: '윤서현', rating: 5, comment: '신선한 재료와 셰프님의 정성이 느껴지는 최고의 오마카세!', date: '2025.01.30' },
          { author: '정태영', rating: 5, comment: '특별한 날 방문하기 좋은 곳입니다. 강력 추천!', date: '2025.01.26' },
        ],
        amenities: [
          { name: '무료 Wi-Fi', available: true },
          { name: '주차 가능', available: true },
          { name: '장애인 편의', available: false },
        ],
      },
      {
        id: 4,
        name: '정원 카페 온',
        category: '카페',
        description: '순천만 정원이 보이는 힐링 카페',
        rating: 4.7,
        address: '전남 순천시 국가정원1호길 47',
        phone: '061-456-7890',
        keywords: ['자연', 'SNS 핫플', '카페', '뷰맛집'],
        lat: 34.8923,
        lng: 127.5012,
        image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=800',
        openTime: '10:00 - 20:00',
        menu: [
          { name: '아메리카노', price: '5,500원' },
          { name: '카페라떼', price: '6,000원' },
          { name: '수제 케이크', price: '7,000원' },
          { name: '브런치 세트', price: '15,000원' },
        ],
        reviews: [
          { author: '송하나', rating: 5, comment: '정원 뷰가 너무 예뻐요. 힐링하기 좋은 카페입니다!', date: '2025.01.29' },
          { author: '한지우', rating: 4.5, comment: '커피도 맛있고 분위기도 좋아요. 데이트 코스로 추천!', date: '2025.01.24' },
        ],
        amenities: [
          { name: '무료 Wi-Fi', available: true },
          { name: '주차 가능', available: true },
          { name: '장애인 편의', available: true },
        ],
      },
      {
        id: 5,
        name: '낙안읍성 전통찻집',
        category: '카페',
        description: '한옥에서 즐기는 전통차와 디저트',
        rating: 4.5,
        address: '전남 순천시 낙안면 동내리 2-1',
        phone: '061-567-8901',
        keywords: ['전통', '자연', '카페'],
        lat: 34.9823,
        lng: 127.3456,
        image: 'https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=800',
        openTime: '09:00 - 19:00',
        menu: [
          { name: '대추차', price: '6,000원' },
          { name: '유자차', price: '6,000원' },
          { name: '전통 한과 세트', price: '12,000원' },
          { name: '떡 세트', price: '10,000원' },
        ],
        reviews: [
          { author: '오예진', rating: 5, comment: '한옥 분위기에서 마시는 전통차가 정말 운치있어요.', date: '2025.01.27' },
          { author: '임동현', rating: 4, comment: '조용하고 차분한 분위기가 좋습니다.', date: '2025.01.18' },
        ],
        amenities: [
          { name: '무료 Wi-Fi', available: false },
          { name: '주차 가능', available: true },
          { name: '장애인 편의', available: false },
        ],
      },
      {
        id: 6,
        name: '순천만 해물집',
        category: '한식',
        description: '싱싱한 해산물로 만든 순천의 대표 맛집',
        rating: 4.8,
        address: '전남 순천시 해룡면 신성리 456',
        phone: '061-678-9012',
        keywords: ['전통', '한식', '가성비'],
        lat: 34.8756,
        lng: 127.5345,
        image: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=800',
        openTime: '10:00 - 21:30',
        menu: [
          { name: '해물탕 (대)', price: '50,000원' },
          { name: '해물탕 (중)', price: '35,000원' },
          { name: '생선구이 정식', price: '15,000원' },
          { name: '회정식', price: '30,000원' },
        ],
        reviews: [
          { author: '서진우', rating: 5, comment: '해물이 정말 신선하고 푸짐해요. 가성비 최고!', date: '2025.01.31' },
          { author: '문지현', rating: 4.5, comment: '순천 오면 꼭 들러야 하는 맛집입니다.', date: '2025.01.23' },
        ],
        amenities: [
          { name: '무료 Wi-Fi', available: true },
          { name: '주차 가능', available: true },
          { name: '장애인 편의', available: true },
        ],
      },
      {
        id: 7,
        name: '모던 브런치 카페',
        category: '카페',
        description: '감각적인 인테리어와 맛있는 브런치',
        rating: 4.6,
        address: '전남 순천시 연향동 1234-5',
        phone: '061-789-0123',
        keywords: ['모던', 'SNS 핫플', '카페'],
        lat: 34.9612,
        lng: 127.4923,
        image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800',
        openTime: '09:00 - 21:00',
        menu: [
          { name: '에그베네딕트', price: '14,000원' },
          { name: '팬케이크 세트', price: '13,000원' },
          { name: '샌드위치 세트', price: '12,000원' },
          { name: '플랫화이트', price: '5,500원' },
        ],
        reviews: [
          { author: '배소연', rating: 5, comment: '브런치 메뉴가 다양하고 맛있어요. 인스타 감성!', date: '2025.02.01' },
          { author: '황민규', rating: 4.5, comment: '분위기 좋고 커피도 맛있습니다.', date: '2025.01.21' },
        ],
        amenities: [
          { name: '무료 Wi-Fi', available: true },
          { name: '주차 가능', available: false },
          { name: '장애인 편의', available: true },
        ],
      },
    ];

    // 키워드 매칭 점수 계산
    const getMatchScore = (restaurant: Restaurant) => {
      let score = 0;
      keywords.forEach((keyword: string) => {
        if (restaurant.keywords.includes(keyword)) {
          score += 1;
        }
      });
      return score;
    };

    // placeOrder 순서대로 맛집 배정
    const selectedRestaurants: Restaurant[] = [];
    
    // 타입별로 정렬된 맛집 리스트 준비
    const restaurantPool = allRestaurants
      .filter(r => r.category !== '카페')
      .sort((a, b) => getMatchScore(b) - getMatchScore(a));
    
    const cafePool = allRestaurants
      .filter(r => r.category === '카페')
      .sort((a, b) => getMatchScore(b) - getMatchScore(a));
    
    let restaurantIndex = 0;
    let cafeIndex = 0;
    
    // placeOrder 순서대로 하나씩 배정
    placeOrder.forEach((place: PlaceOrder) => {
      if (place.type === 'restaurant' && restaurantIndex < restaurantPool.length) {
        selectedRestaurants.push(restaurantPool[restaurantIndex]);
        restaurantIndex++;
      } else if (place.type === 'cafe' && cafeIndex < cafePool.length) {
        selectedRestaurants.push(cafePool[cafeIndex]);
        cafeIndex++;
      }
    });

    setRestaurants(selectedRestaurants);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto p-3 md:p-4 flex items-center">
          <button
            onClick={() => navigate('/input')}
            className="flex items-center text-gray-600 hover:text-gray-900 mr-2 md:mr-4"
          >
            <ArrowLeft className="w-5 h-5 mr-1 md:mr-2" />
            <span className="text-sm md:text-base">다시 설정</span>
          </button>
          <h1 className="text-xl md:text-2xl text-orange-600">온식 추천 코스</h1>
        </div>
      </div>

      {/* 지도 영역 */}
      <div className="w-full h-[250px] md:h-[400px] bg-gray-200">
        <MapComponent restaurants={restaurants} />
      </div>

      {/* 맛집 리스트 - 가로 스크롤 */}
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        <div className="flex items-center justify-between mb-3 md:mb-4">
          <h2 className="text-lg md:text-2xl">추천 맛집 코스</h2>
          <p className="text-xs md:text-sm text-gray-500">← 드래그 →</p>
        </div>
        <div className="flex gap-3 md:gap-4 overflow-x-auto pb-4 scroll-smooth -mx-4 px-4 md:mx-0 md:px-0">
          {restaurants.map((restaurant, index) => (
            <RestaurantCard
              key={restaurant.id}
              restaurant={restaurant}
              index={index}
              onClick={() => setSelectedRestaurant(restaurant)}
            />
          ))}
        </div>
        
        {/* 스크롤 인디케이터 */}
        {restaurants.length > 2 && (
          <div className="flex justify-center gap-2 mt-4">
            {restaurants.map((_, index) => (
              <div
                key={index}
                className="w-2 h-2 rounded-full bg-gray-300"
              />
            ))}
          </div>
        )}
      </div>

      {/* 상세 정보 모달 */}
      {selectedRestaurant && (
        <RestaurantDetailModal
          restaurant={selectedRestaurant}
          onClose={() => setSelectedRestaurant(null)}
        />
      )}

      <style>{`
        /* 스크롤바 스타일링 - 보이도록 설정 */
        .overflow-x-auto::-webkit-scrollbar {
          height: 8px;
        }
        .overflow-x-auto::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 4px;
        }
        .overflow-x-auto::-webkit-scrollbar-thumb {
          background: #ffa500;
          border-radius: 4px;
        }
        .overflow-x-auto::-webkit-scrollbar-thumb:hover {
          background: #ff8c00;
        }
      `}</style>
    </div>
  );
}