import { createBrowserRouter } from "react-router";
import { InputPage } from "./pages/InputPage";
import { ResultPage } from "./pages/ResultPage";
import { HomePage } from "./pages/HomePage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: HomePage,
  },
  {
    path: "/input",
    Component: InputPage,
  },
  {
    path: "/result",
    Component: ResultPage,
  },
]);
