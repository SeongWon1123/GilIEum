
  # 온식 in 순천

  This is a code bundle for 온식 in 순천. The original project is available at https://www.figma.com/design/xpO0GTnBVhDTg14iiI54bR/%EC%98%A8%EC%8B%9D-in-%EC%88%9C%EC%B2%9C.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  